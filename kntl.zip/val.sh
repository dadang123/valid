
#!/bin/bash
#Update On Sunday, January 13, 2019
RED='\033[0;31m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
ORANGE='\033[0;33m' 
PUR='\033[0;35m'
GRN="\e[32m"
WHI="\e[37m"
NC='\033[0m'
header(){
	printf "${GRN}
	####################################
	####################################
	#######                      #######
	#######                      #######${YELLOW}
	####### www.tatsumi-crew.net #######
	###############      ###############
	###############      ###############
	###############      ###############
	###############      ###############${RED}
	#######    ####      ####    #######
	#######    ####      ####    #######
	#######    ##############    #######
	#######    ##############    #######
	#######                      #######
	####################################
	####################################${NC}
	------------------------------------
	     AppleVal - V0.1 NakoCoders
	------------------------------------
	"
}
updater() {
  read -p "Masukan Password: " password
  echo "Checking integrity file to server..."
  localShellCode=`cat $0 | sha256sum`
  cloudShellCode=`curl "http://nakocoders.org/appleval/update.php?password=$password" -s | sha256sum`
  if [[ $localShellCode != $cloudShellCode ]]; then
    echo "Updating script... Please wait."
    wget "http://nakocoders.org/appleval/update.php?password=$password" -O update.sh
    echo "File successfully updated on `date`."
  else
    echo "Script are up to date"
  fi
  exit 1
}
while getopts ":i:r:l:t:dchu" o; do
    case "${o}" in
        u)
            updater
            ;;
    esac
done
login(){
	getsession 
	random=$(echo $(shuf -i 0-999999 -n 1))
	ua=$(cat ua.txt | sort -R | head -1)
	SECONDS=0
	ambil=$(curl -s --compressed --cookie ${random}_tmp "https://appleid.apple.com/account/validation/appleid" -L \
	-H 'User-Agent: '$ua'' \
	-H 'Accept-Encoding: gzip, deflate, br' \
	-H 'Accept: application/json, text/javascript, */*; q=0.01' \
	-H 'Accept-Language: en-US,en;q=0.5' \
	-H 'Referer: https://appleid.apple.com/account' \
	-H 'Content-Type: application/json' \
	-H 'scnt: '$scnt'' \
	-H 'X-Apple-ID-Session-Id: '$sessionId'' \
	-H 'X-Apple-Request-Context: create' \
	-H 'X-Apple-Api-Key: cbf64fd6843ee630b463f358ea0b707b' \
	-H 'X-Requested-With: XMLHttpRequest' \
	-H 'Connection: keep-alive' \
	-H 'Cookie: ndcd=wc1.1.w-046483.1.2.0SrkY3tXtqx5Fh5F91--LA%252C%252C.gVSxxbvw3FkKZDf2-oNT-J4v0MeQeqCpkXrvsGCunnMFUALJGbmcuTHIcvSPS3aDuywIgQ7xknwyCOFl08MrpjcGOyRfPg-iDatsgtz6ieRIXh4CTXPHnwlLt_Sz6CtWETy4mEGf5K3f6IHWYtj4C2GA6VHE3awfLgYDQ5nJxspDdGp5BomW9xIbM0Te464X; idclient=web; dslang=US-EN; site=USA; aidsp='"$sessionId"'; geo=ID; ccl=jC0OV8+lMCx8lc7D3FFsRg=='  \
	--data '{"emailAddress":"'$1'"}')
	duration=$SECONDS
	valid=$(echo $ambil | grep -Po '(?<="used" : )[^,]*')
	icloudvalid=$(echo $ambil | grep -Po '(?="appleOwnedDomain" : )[^,]*')
	if [[ $valid =~ 'true' ]]; then
		printf "${NC}${GRN}[LIVE/$valid] => $1 [AppleVal - NakoCoders]\n";
		echo "[LIVE] => $1">>result/live.txt
	elif [[ $icloudvalid =~ 'true' ]]; then
		printf "${GRN}[LIVE/$valid] => $1 [AppleVal - NakoCoders]\n";
		echo "LIVE => $1">>result/live.txt
	else
		printf "${NC}${RED}[DIE/$valid] => $1 [AppleVal - NakoCoders]\n";
		echo "DIE => $1">>result/die.txt
	fi
}
getsession() {
	ua=$(cat ua.txt | sort -R | head -1)
	wait
	resp=`curl 'https://appleid.apple.com/account' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' -H 'Connection: keep-alive' -H 'Accept-Encoding: gzip, deflate, br' -H 'Accept-Language: en-US,en;q=0.9,id;q=0.8,fr;q=0.7,la;q=0.6' -H 'Upgrade-Insecure-Requests: 1' -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36' --compressed -D - -s -o /dev/null`
	scnt="$(echo "$resp" | grep "scnt: " | cut -c7- | xargs)"
	sessionId="$(echo "$resp" | grep "aidsp" | awk -F[=\;] '{print $2}' | xargs)"
	apiKey='cbf64fd6843ee630b463f358ea0b707b'
	if [[ $scnt == '' || $sessionId == '' || $apiKey = '' ]]; then
		sleep 4
		echo "IP Blocked by Apple."
		getsession
		sleep 2
	fi
}
if [[ ! -d result ]]; then
	mkdir result
	touch result/live.txt
	touch result/die.txt
fi
if [[ ! -d tmp ]]; then
	mkdir tmp
fi
header
echo ""
echo "List In This Directory : "
ls
echo "Delimeter list -> email"
echo -n "Masukan File List : "
read list
if [ ! -f $list ]; then
	echo "$list No Such File"
	exit
fi
persend=4
setleep=10
x=$(gawk '{ print $1 }' $list)
IFS=$'\r\n' GLOBIGNORE='*' command eval  'valid=($x)'
itung=1
for (( i = 0; i < "${#valid[@]}"; i++ )); do
	set_kirik=$(expr $itung % $persend)
	if [[ $set_kirik == 0 && $itung > 0 ]]; then
		sleep $setleep
	fi
	emails="${valid[$i]}"
	login $emails &
	itung=$[$itung+1]  
done
wait
